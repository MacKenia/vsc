package xyz.mac.mapping;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import org.apache.ibatis.annotations.Mapper;

import xyz.mac.model.StudentNs;

@Mapper
public interface StudentNsMapper extends BaseMapper<StudentNs>{
    
}
