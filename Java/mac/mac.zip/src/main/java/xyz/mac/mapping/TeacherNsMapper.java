package xyz.mac.mapping;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import org.apache.ibatis.annotations.Mapper;
import xyz.mac.model.TeacherNs;

@Mapper
public interface TeacherNsMapper extends BaseMapper<TeacherNs> {
    
}
