package xyz.mac.services;

import com.baomidou.mybatisplus.extension.service.IService;

import xyz.mac.model.CqnuStu;

public interface CqnuStuService extends IService<CqnuStu> {
    
}
