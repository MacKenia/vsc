package xyz.mac.services;


import com.baomidou.mybatisplus.extension.service.IService;

import xyz.mac.model.StudentNs;

public interface StudentNsService extends IService<StudentNs> {

}
