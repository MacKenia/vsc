package xyz.mac.services;

import java.util.List;

import xyz.mac.model.Student;

public interface StudentService {
    List<Student> getAllStudents();
}
