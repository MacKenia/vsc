package xyz.mac.services;

import com.baomidou.mybatisplus.extension.service.IService;

import xyz.mac.model.TeacherNs;

public interface TeacherNsService extends IService<TeacherNs> {
    
}
