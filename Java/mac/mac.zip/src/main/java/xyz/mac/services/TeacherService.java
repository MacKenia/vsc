package xyz.mac.services;

import java.util.List;

import xyz.mac.model.Teacher;

public interface TeacherService {
    List<Teacher> getAllTeachers();
}
